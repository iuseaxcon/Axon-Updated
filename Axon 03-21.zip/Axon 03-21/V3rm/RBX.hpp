
#pragma once
#include <Windows.h>
#include "RetCheck.hpp"
extern "C" {
#include "Lua\lua.h"
#include "Lua\lua.hpp"
#include "Lua\lualib.h"
#include "Lua\lauxlib.h"
#include "Lua\luaconf.h"
#include "Lua\llimits.h"
}

DWORD RobloxState;
lua_State* VanillaState;
std::vector<int> int3breakpoints;
HWND IsActive;
int registry;
int vanillaFunctionBridge(lua_State* L);

#define R_LUA_TNIL 0
#define R_LUA_TLIGHTUSERDATA 2
#define R_LUA_TNUMBER 3
#define R_LUA_TBOOLEAN 1
#define R_LUA_TSTRING 4
#define R_LUA_TTHREAD 8
#define R_LUA_TFUNCTION 7
#define R_LUA_TTABLE 6
#define R_LUA_TUSERDATA 5
#define R_LUA_TPROTO 9
#define R_LUA_TUPVALUE 10

#define x(x) (x - 0x400000 + (DWORD)GetModuleHandleA(0))

DWORD ScriptContextVFTable = x(0x1c40458);

typedef char(__stdcall* rgetfield)(int a1, int a2, const char* a3);
rgetfield r_lua_getfield = (rgetfield)unprotect(x(0x7c8b60));

typedef char* (__fastcall* rtolstring)(DWORD rL, int idx, size_t* size);
rtolstring r_lua_tolstring = (rtolstring)(unprotect(x(0x7cb4a0)));

typedef void(__cdecl* rsettop)(DWORD rL, int idx);
rsettop r_lua_settop = (rsettop)(unprotect(x(0x7cb260)));

typedef bool(__cdecl* toboolean)(DWORD rL, bool idx);
toboolean r_lua_toboolean = (toboolean)(x(0x7cb3e0));

typedef void(__cdecl* pushvalue)(DWORD rL, DWORD idx);
pushvalue r_lua_pushvalue = (pushvalue)(unprotect(x(0x7ca220)));

typedef double(__cdecl* pushnumber)(DWORD rL, double idx);
pushnumber r_lua_pushnumber = (pushnumber)(unprotect(x(0x7ca040)));

typedef void(__stdcall* rpushstring)(DWORD rL, const char*);
rpushstring r_lua_pushstring = (rpushstring)(x(0x7ca0c0));

typedef int(__cdecl* rpnigger)(DWORD, int, int, int);
rpnigger r_lua_pcall = (rpnigger)(unprotect(x(0x7c9a90)));

typedef void(__cdecl* pushnil)(DWORD);
pushnil r_lua_pushnil = (pushnil)(unprotect(x(0x7c9fd0)));

typedef DWORD(__cdecl* next2)(DWORD rL, int idx);
next2 r_lua_next = (next2)(Retcheck::unprotect((BYTE*)(x(0x7c97f0))));

typedef int(__cdecl* rboolean)(unsigned int, int);
rboolean r_lua_pushboolean = (rboolean)(unprotect(x(0x7c9b60)));

typedef double(__cdecl* rtnumber)(int a1, signed int a2, DWORD* a3);
rtnumber r_lua_tonumber = (rtnumber)(unprotect(x(0x7cb5d0)));

typedef void(__cdecl* rpushcclosure)(DWORD, DWORD, DWORD, DWORD);
rpushcclosure r_lua_pushcclosure = (rpushcclosure)(unprotect(x(0x7c9be0)));

typedef void(__cdecl* rcreatetable)(DWORD rL, int num, int fix);
rcreatetable r_lua_createtable = (rcreatetable)(unprotect(x(0x7c8730)));

typedef DWORD(__cdecl* rnewthread)(DWORD);
rnewthread r_lua_newthread = (rnewthread)unprotect(x(0x7c9590));

typedef int(__cdecl* rnewusernigger)(int a1, unsigned int a2, char a3);
rnewusernigger r_lua_newuserdata = (rnewusernigger)(unprotect(x(0x7c96d0)));

typedef void(__cdecl* rrawgeti)(DWORD, DWORD, DWORD);
rrawgeti r_lua_rawgeti = (rrawgeti)unprotect(x(0x7ca4d0));

typedef void* (__cdecl* rgetmetatable)(DWORD rL, int idx);
rgetmetatable r_lua_getmetatable = (rgetmetatable)(unprotect(x(0x7c8f00)));

typedef int(__cdecl* rtonigger)(DWORD, int);
rtonigger r_lua_touserdata = (rtonigger)(unprotect(x(0x7cb730)));

typedef DWORD(__cdecl* rtype)(DWORD, int);
rtype r_lua_type = (rtype)(x(0x7cb790));

typedef DWORD(__cdecl* rref)(DWORD, DWORD);
rref r_luaL_ref = (rref)(unprotect(x(0x7c3be0)));

typedef void* (__cdecl* rsettable)(DWORD rL, int);
rsettable r_lua_settable = (rsettable)(unprotect(x(0x7cb1d0)));

typedef void(__cdecl*rpushlight)(DWORD, void*);
rpushlight r_lua_pushlightuserdata = (rpushlight)(unprotect(x(0x7c9ea0)));

int __cdecl r_lua_gettop(int a1)
{
    return (*(DWORD*)(a1 + 0xc) - *(DWORD*)(a1 + 0x10)) >> 4;
}

void SetLevel(DWORD RobloxState, int Level) {
	int v3 = *(DWORD*)(RobloxState + 0x84);
	*(DWORD*)(v3 + 0x18) = Level;
}

DWORD SetRState(DWORD v2){
    return *(DWORD*)(v2 + 0xac) - (v2 + 0xac);
}

#define r_lua_tostring(rL,i)	r_lua_tolstring(rL, (i), NULL)
#define r_lua_pop(rL,n)		r_lua_settop(rL, -(n)-1)
#define r_lua_getglobal(rL,s)	r_lua_getfield(rL, LUA_GLOBALSINDEX, (s))
#define r_lua_newtable(rL) r_lua_createtable(rL, 0, 0)