

#include "Wrapper.hpp"
#include <CommCtrl.h>
#include <Wininet.h>
#include <fstream>
#include <intrin.h>
#include <Tlhelp32.h>
#pragma comment(lib, "wininet.lib")


DWORD WINAPI input(PVOID lvpParameter)
{
	std::string WholeScript = "";
	HANDLE hPipe;
	char buffer[999999];
	DWORD dwRead;
	hPipe = CreateNamedPipe(TEXT("\\\\.\\pipe\\Axon"),//change ur pipe skid
		PIPE_ACCESS_DUPLEX | PIPE_TYPE_BYTE | PIPE_READMODE_BYTE,
		PIPE_WAIT,
		1,
		999999,
		999999,
		NMPWAIT_USE_DEFAULT_WAIT,
		NULL);
	while (hPipe != INVALID_HANDLE_VALUE)
	{
		if (ConnectNamedPipe(hPipe, NULL) != FALSE)
		{
			while (ReadFile(hPipe, buffer, sizeof(buffer) - 1, &dwRead, NULL) != FALSE)
			{
				buffer[dwRead] = '\0';
				try {
					try {
						WholeScript = WholeScript + buffer;
					}
					catch (...) {
					}
				}
				catch (std::exception e) {

				}
				catch (...) {

				}
			}
			luaL_dostring(VanillaState,WholeScript.c_str()); //magic :TM:
			WholeScript = "";
		}
		DisconnectNamedPipe(hPipe);
	}
}


namespace Scanner {
	BOOL compare(const BYTE* location, const BYTE* aob, const char* mask) {
		for (; *mask; ++aob, ++mask, ++location) {
			__try {
				if (*mask == 'x' && *location != *aob)
					return 0;
			}
			__except (EXCEPTION_EXECUTE_HANDLER) {
				return 0;
			}
		}
		return 1;
	}
	DWORD find_Pattern(BYTE* pattern, char* mask, BYTE protection = (PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) {
		SYSTEM_INFO SI = { 0 };
		GetSystemInfo(&SI);
		DWORD start = (DWORD)SI.lpMinimumApplicationAddress;
		DWORD end = (DWORD)SI.lpMaximumApplicationAddress;
		MEMORY_BASIC_INFORMATION mbi;
		while (start < end && VirtualQuery((void*)start, &mbi, sizeof(mbi))) {
			if ((mbi.State & MEM_COMMIT) && (mbi.Protect & protection) && !(mbi.Protect & PAGE_GUARD)) {
				for (DWORD i = (DWORD)mbi.BaseAddress; i < (DWORD)mbi.BaseAddress + mbi.RegionSize; ++i) {
					if (compare((BYTE*)i, pattern, mask)) {
						return i;
					}
				}
			}
			start += mbi.RegionSize;
		}
		return 0;
	}
	int Scan(DWORD mode, char* content, char* mask) {
		return find_Pattern((BYTE*)content, mask, mode);
	}
}

BOOL WINAPI CONSOLEBYPASS()
{
	DWORD nOldProtect;
	if (!VirtualProtect(FreeConsole, 1, PAGE_EXECUTE_READWRITE, &nOldProtect))
		return FALSE;
	*(BYTE*)(FreeConsole) = 0xC3; //opcode time
	if (!VirtualProtect(FreeConsole, 1, nOldProtect, &nOldProtect))
		return FALSE;
	AllocConsole();
}

void main()
{
	CONSOLEBYPASS();
	freopen("CONOUT$", "w", stdout);
	freopen("CONIN$", "r", stdin);
	HWND ConsoleHandle = GetConsoleWindow();
	SetWindowPos(ConsoleHandle, HWND_TOPMOST, 50, 20, 0, 0, SWP_DRAWFRAME | SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
	ShowWindow(ConsoleHandle, 1);
	SetConsoleTitle("Axon");
	DWORD v2 = Scanner::Scan(PAGE_READWRITE, (char*)&ScriptContextVFTable, (char*)"xxxx");
	Sleep(500);
	RobloxState = SetRState(v2);
	VanillaState = luaL_newstate();
	BreakPointsInit();
	luaL_openlibs(VanillaState);
	luaL_newmetatable(VanillaState, "garbagecollector");
	lua_pushcfunction(VanillaState, UserDataGC);
	lua_setfield(VanillaState, -2, "__gc");
	lua_pushvalue(VanillaState, -1);
	lua_setfield(VanillaState, -2, "__index");
	WrapGlobals(RobloxState, VanillaState);
	SetLevel(RobloxState, 6);
	lua_newtable(VanillaState);
	lua_setglobal(VanillaState, "_G");
	luaL_dostring(VanillaState,"game.StarterGui:SetCore('SendNotification', {Duration = 4; Title='Korona'; Text='Nusimesk tona ;)'})");
	CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)input, NULL, NULL, NULL);
	std::string i;
	while (true) {
		getline(std::cin, i);
		luaL_dostring(VanillaState,i.c_str());
		i = "";
	}
}

BOOL APIENTRY DllMain(HMODULE Module, DWORD Reason, void* Reserved)
{
	if(Reason == DLL_PROCESS_ATTACH)
	{
		DisableThreadLibraryCalls(Module);
		CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)main, NULL, NULL, NULL);
	}
	return TRUE;
}